package homework;

public class evenback {
	public static void main(String[]aargs) {
		int i=10;
		 while(i>=1)
		 {
			 if(i%2==0) {
			 System.out.println(i);
			 
		 }
			 i--;
	}
}

}
