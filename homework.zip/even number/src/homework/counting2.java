package homework;

public class counting2 {
	public static void main(String[]aargs) {
		int i=1;
		 while(i<=10)
		 {
			 System.out.println(i);
			 i++;
		 }
	}

}
