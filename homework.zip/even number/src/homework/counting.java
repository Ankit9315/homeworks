package homework;
public class counting {
	public static void main(String[]aargs) {
		int i=10;
		 while(i>=1)
		 {
			 System.out.println(i);
			 i--;
		 }
	}

}
