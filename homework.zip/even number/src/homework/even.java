package homework;

public class even {
	public static void main(String[]aargs) {
		int i=1;
		 while(i<=10)
		 {
			 if(i%2==0) {
			 System.out.println(i);
			 
		 }
			 i++;
	}
}
}
